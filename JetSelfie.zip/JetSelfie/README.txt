جنگنده سلفی - پروژهٔ اندروید
راه ساخت APK بدون کامپیوتر: این پوشه رو توی یه مخزن GitHub آپلود کن، تب Actions ← Build APK ← فایل JetSelfie-apk رو دانلود کن.
راه کامپیوتر: پوشه رو توی Android Studio باز کن و Build ← Build APK.
