package com.example.jetselfie

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView

class OverlayService : Service() {

    companion object {
        const val ACTION_TEST = "com.example.jetselfie.TEST"
        private const val CHANNEL = "jet_selfie"
        private const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private var hotspot: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addHotspot()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TEST) flyJet()
        return START_STICKY
    }

    override fun onDestroy() {
        hotspot?.let { runCatching { wm.removeView(it) } }
        hotspot = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(28)
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jet Selfie", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("جنگنده سلفی فعاله")
            .setContentText("دو بار روی دوربین سلفی بزن")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun applyCutout(lp: WindowManager.LayoutParams) {
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    /** A small invisible touch area exactly over the front camera (top centre). */
    private fun addHotspot() {
        val v = View(this)
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                flyJet()
                return true
            }
        })
        v.setOnTouchListener { _, e -> detector.onTouchEvent(e) }

        val lp = WindowManager.LayoutParams(
            dp(80), maxOf(statusBarHeight(), dp(28)),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.x = 0
        lp.y = 0
        applyCutout(lp)
        wm.addView(v, lp)
        hotspot = v
    }

    /** The jet grows out of the camera hole and flies off to the left. */
    private fun flyJet() {
        val sw = resources.displayMetrics.widthPixels
        val jetW = (sw * 0.75f).toInt()
        val jetH = (jetW * 237f / 900f).toInt()
        val holeY = maxOf(statusBarHeight(), dp(28)) / 2

        val root = FrameLayout(this)
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.jet)
            scaleType = ImageView.ScaleType.FIT_XY
            alpha = 0f
            scaleX = 0.06f
            scaleY = 0.06f
            pivotX = jetW / 2f
            pivotY = jetH / 2f
        }
        root.addView(iv, FrameLayout.LayoutParams(jetW, jetH).apply {
            leftMargin = sw / 2 - jetW / 2
            topMargin = holeY - jetH / 2
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        applyCutout(lp)
        wm.addView(root, lp)

        val total = 2200L
        val fadeIn = ObjectAnimator.ofFloat(iv, View.ALPHA, 0f, 1f).setDuration(250)
        val sx = ObjectAnimator.ofFloat(iv, View.SCALE_X, 0.06f, 1f).setDuration(900)
        val sy = ObjectAnimator.ofFloat(iv, View.SCALE_Y, 0.06f, 1f).setDuration(900)
        sx.interpolator = DecelerateInterpolator()
        sy.interpolator = DecelerateInterpolator()
        val tx = ObjectAnimator.ofFloat(iv, View.TRANSLATION_X, 0f, -(sw / 2f + jetW)).setDuration(total)
        tx.interpolator = AccelerateInterpolator(1.1f)
        val ty = ObjectAnimator.ofFloat(iv, View.TRANSLATION_Y, 0f, dp(110).toFloat()).setDuration(total)

        AnimatorSet().apply {
            playTogether(fadeIn, sx, sy, tx, ty)
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    runCatching { wm.removeView(root) }
                }
            })
            start()
        }
    }
}
