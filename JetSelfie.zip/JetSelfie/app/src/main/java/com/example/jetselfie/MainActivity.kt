package com.example.jetselfie

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(s: String, size: Float = 16f) = TextView(this).apply {
            text = s
            textSize = size
            setPadding(0, pad / 2, 0, pad / 2)
        }

        fun button(s: String, action: () -> Unit) = Button(this).apply {
            text = s
            setOnClickListener { action() }
        }

        col.addView(label("✈️ جنگنده سلفی", 26f))
        col.addView(label("بعد از فعال‌سازی، هر جای گوشی (از جمله صفحهٔ اصلی) دو بار روی دوربین سلفی بزنی، جنگنده از همون‌جا رد می‌شه."))
        col.addView(label("مرحلهٔ ۱"))
        col.addView(button("اجازهٔ نمایش روی سایر برنامه‌ها") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(label("مرحلهٔ ۲"))
        col.addView(button("فعال‌سازی") { enable() })
        col.addView(button("تست جنگنده") { test() })
        col.addView(button("توقف") { stopService(Intent(this, OverlayService::class.java)) })
        col.addView(
            label(
                "نکتهٔ شیائومی/ردمی: تنظیمات ← برنامه‌ها ← جنگنده سلفی ← «شروع خودکار» رو روشن کن و «صرفه‌جویی باتری» رو روی «بدون محدودیت» بذار تا سیستم برنامه رو نبنده."
            )
        )

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun enable() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اول اجازهٔ مرحلهٔ ۱ رو بده", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "فعال شد. حالا دو بار روی دوربین سلفی بزن", Toast.LENGTH_LONG).show()
    }

    private fun test() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اول اجازهٔ مرحلهٔ ۱ رو بده", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(
            Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_TEST)
        )
    }
}
